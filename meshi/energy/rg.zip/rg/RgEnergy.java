package meshi.energy.rg;

import meshi.energy.*;
import meshi.molecularElements.atoms.*;
import meshi.util.Updateable;
import meshi.util.UpdateableException;

public class RgEnergy extends AbstractEnergy {
    public Atom testAtom = null;
    private final RgParameters n_RGhSS                                  = RgParameters.n_RGhSS;
    private final RgParameters RGhSS_RGhCoilCentered = RgParameters.RGhSS_RGhCoilCentered;
    private final RgParameters RGhSS_RGbSScentered      = RgParameters.RGhSS_RGbSScentered;
    private final RgParameters RGhSS_RGbCoilCentered = RgParameters.RGhSS_RGbCoilCentered;
    private final RgParameters RGhSS_RGcSScentered     = RgParameters.RGhSS_RGcSScentered;
    private final RgParameters RGhSS_RGcCoilCentered = RgParameters.RGhSS_RGcCoilCentered;
    private final RgParameters RGhSS_RGbSS                        = RgParameters.RGhSS_RGbSS;
    private final RgParameters RGhSS_RGcSS                        = RgParameters.RGhSS_RGcSS;

    private final double logN;
    private final LogRadiusOfGyration logNonPolarSsRG;
    private final LogRadiusOfGyration logNonPolarCoilRG;
    private final LogRadiusOfGyration logBackboneSsRG;
    private final LogRadiusOfGyration logBackboneCoilRG;
    private final LogRadiusOfGyration logPolarSsRG;
    private final LogRadiusOfGyration logPolarCoilRG;
   private final CenterOfMass   centerOfMass, backboneCenterOfMass;
   private final RadiusOfGyration nonPolarRG, backboneRG, polarRG;

    public RgEnergy(Updateable[] updateables, LogRadiusOfGyration[] logRgArray, double logN, double weight) {
        super(updateables, weight);
	    comment = "RG";
        this.logN=logN;
         logNonPolarSsRG     = logRgArray[0];
        logNonPolarCoilRG  = logRgArray[1];
        logBackboneSsRG       = logRgArray[2];
        logBackboneCoilRG   = logRgArray[3];
        logPolarSsRG               = logRgArray[4];
        logPolarCoilRG          = logRgArray[5];
        centerOfMass               = (CenterOfMass) updateables[0];
        backboneCenterOfMass = (CenterOfMass) updateables[1];
        nonPolarRG = logNonPolarSsRG.rg;
        backboneRG = logBackboneSsRG.rg;
        polarRG = logPolarSsRG.rg;
    }

    public void evaluateAtoms() {}

    public double evaluate() {
        double energy = 0;
        if (! on) return 0;
        energy += evaluateN_RGhSS();
        energy += evaluateRGratio(centerOfMass, logNonPolarSsRG,logNonPolarCoilRG, RGhSS_RGhCoilCentered, testAtom);
        energy += evaluateRGratio(centerOfMass, logNonPolarSsRG,logBackboneSsRG, RGhSS_RGbSScentered,      testAtom);
        energy += evaluateRGratio(centerOfMass, logNonPolarSsRG,logBackboneCoilRG, RGhSS_RGbCoilCentered,  testAtom);
        energy += evaluateRGratio(centerOfMass, logNonPolarSsRG,logPolarSsRG, RGhSS_RGcSScentered,        testAtom);
        energy += evaluateRGratio(centerOfMass, logNonPolarSsRG,logPolarCoilRG, RGhSS_RGcCoilCentered,    testAtom);
        energy += evaluateRGratio(centerOfMass, logNonPolarSsRG,logBackboneSsRG, RGhSS_RGbSS,        testAtom);
        energy += evaluateRGratio(centerOfMass, logNonPolarSsRG,logPolarSsRG, RGhSS_RGbSS,    testAtom);
        energy += evaluateLinearRG(centerOfMass, nonPolarRG,1);
        energy += evaluateLinearRG(backboneCenterOfMass,backboneRG,1);
          energy += evaluateLinearRG(centerOfMass,polarRG,-0.1);
          return energy;
    }


    private double evaluateLinearRG(CenterOfMass centerOfMass, RadiusOfGyration radiusOfGyration, double factor) {
        double rg = radiusOfGyration.radiusOfGyration();
        double energy = weight*factor*rg;
        Atom atom;
        int size = radiusOfGyration.size();
        int sizeCM = centerOfMass.size();

        for (int i = 0; i < size; i++) {
            atom = radiusOfGyration.atomAt(i);
            atom.addToFx(-weight*factor*radiusOfGyration.dRGdX(i));
            atom.addToFy(-weight*factor*radiusOfGyration.dRGdY(i));
            atom.addToFz(-weight*factor*radiusOfGyration.dRGdZ(i));
        }
        for (int i = 0; i < sizeCM; i++) {
            atom = centerOfMass.atomAt(i);
            atom.addToFx(-weight*factor*radiusOfGyration.dRGdCMX());
            atom.addToFy(-weight*factor*radiusOfGyration.dRGdCMy());
            atom.addToFz(-weight*factor*radiusOfGyration.dRGdCMz());
        }
        return energy;



    }
    private double evaluateN_RGhSS() {
        double energy=0;
        double logRG   = logNonPolarSsRG.logRG();
        double dRatio = 1/(n_RGhSS.alpha*logN);
        double ratio   = (logRG -n_RGhSS.beta)*dRatio;

        double diffU = ratio - n_RGhSS.upperLimit;
        double diffL = ratio - n_RGhSS.lowerLimit;
        double diff;
        if ((diffU <= 0) && (diffL >= 0)) return 0;
        if (diffU > 0) diff = diffU;
        else                 diff = diffL;
        diff=100*diff;
        double diff3 = diff*diff*diff;
        double diff4= diff3*diff;
        energy = weight*diff4;

        int size = logNonPolarSsRG.size();
        Atom atom;
        for (int i = 0 ; i<size;i++) {
                atom = logNonPolarSsRG.atomAt(i);
                //System.out.println("xxxxx "+energy+"  "+weight*2*diff*dRatio*logNonPolarSsRG.dLogRGdX(i));
                atom.addToFx(-weight*400*diff3*dRatio*logNonPolarSsRG.dLogRGdX(i));
                atom.addToFy(-weight*400*diff3*dRatio*logNonPolarSsRG.dLogRGdY(i));
                atom.addToFz(-weight*400*diff3*dRatio*logNonPolarSsRG.dLogRGdZ(i));
        }
        return energy;
    }

    public void test(TotalEnergy totalEnergy, Atom atom) {
            System.out.println(" testing RgEnergy using "+atom);
            if (! on) {
                System.out.println(""+this +" is off");
                return;
            }
            testAtom = atom;
                double[][] coordinates = new double[3][];
                        coordinates[0] = atom.X();
                        coordinates[1] = atom.Y();
                        coordinates[2] = atom.Z();
                        for(int i = 0; i< 3; i++) {
                            try{totalEnergy.update();}catch(UpdateableException ue){}
                            double x = coordinates[i][0];
                            coordinates[i][1] = 0;
                            double e1 = evaluate();
                            double analiticalForce = coordinates[i][1];
                            coordinates[i][0] += EnergyElement.DX;
                            // Whatever should be updated ( such as distance matrix torsion list etc. )
                            try{totalEnergy.update();}catch(UpdateableException ue){}
                            double e2 = evaluate();
                            double de = e2-e1;
                            double numericalForce = - de/EnergyElement.DX;
                            coordinates[i][0] -= EnergyElement.DX;
                             try{totalEnergy.update();}catch(UpdateableException ue){}

                            double diff = Math.abs(analiticalForce - numericalForce);

                            if (Math.abs(analiticalForce-numericalForce)>0.00001){
                            //if ((2*diff/(Math.abs(analiticalForce)+Math.abs(numericalForce)+VERY_SMALL)) > relativeDiffTolerance){
                                System.out.println("Testing "+this);
                                System.out.println("Atom["+atom.number()+"]."+EnergyElement.XYZ.charAt(i)+" = "+x);
                                System.out.println("Analytical force = "+analiticalForce);
                                System.out.println("Numerical force  = "+numericalForce);


                                System.out.println("diff = "+diff+"\n"+
                                                   "tolerance = 2*diff/(|analiticalForce| + |numericalForce|+VERY_SMALL) = "+
                                                   2*diff/(Math.abs(analiticalForce) + Math.abs(numericalForce)+EnergyElement.VERY_SMALL));
                                System.out.println();
                            }
                            if ((e1 == AbstractEnergy.INFINITY) | (e1 == AbstractEnergy.NaN))
                                System.out.println("Testing "+this+"\ne1 = "+e1);
                            if ((e2 == AbstractEnergy.INFINITY) | (e2 == AbstractEnergy.NaN))
                                System.out.println("Testing "+this+"\ne2 = "+e2);
                            if ((analiticalForce == AbstractEnergy.INFINITY) | (analiticalForce == AbstractEnergy.NaN))
                                System.out.println("Testing "+this+"\nanaliticalForce = "+analiticalForce);
            }



        }

         private double evaluateRGratio(CenterOfMass centerOfMass, LogRadiusOfGyration logRG1, LogRadiusOfGyration logRG2, RgParameters parameters, Atom testAtom) {
            double energy = 0;
             double scale = 1;

            int size1 = logRG1.size();
            int size2 = logRG2.size();
            int sizeCM = centerOfMass.size();
            double logRg1=logRG1.logRG();


        double logRg2=logRG2.logRG();

        double ratio = (logRg2-parameters.beta)/(logRg1*parameters.alpha);
        double diffU = ratio - parameters.upperLimit;
        double diffL = ratio - parameters.lowerLimit;
        double diff;
        if ((diffU <= 0) && (diffL >= 0)) return 0;
        if (diffU > 0) diff = diffU;
        else                 diff = diffL;
        double diff3 = diff*diff*diff;
        double diff4 = diff3*diff;
        energy = scale*weight*diff4;
         

         //
        double dEnergy = scale*weight*4*diff3;

        double dEnergyDrg1 = -dEnergy*(logRG2.logRG()-parameters.beta)/(logRG1.logRG()*logRG1.logRG()*parameters.alpha);
        double dEnergyDrg2 = dEnergy/(logRG1.logRG()*parameters.alpha);
        double dEnergyDcmX = dEnergyDrg1*logRG1.dLogRGdCMx()+dEnergyDrg2*logRG2.dLogRGdCMx();
        double dEnergyDcmY = dEnergyDrg1*logRG1.dLogRGdCMy()+dEnergyDrg2*logRG2.dLogRGdCMy();
        double dEnergyDcmZ = dEnergyDrg1*logRG1.dLogRGdCMz()+dEnergyDrg2*logRG2.dLogRGdCMz();

        Atom atom;
        for (int i = 0 ; i<size1;i++) {
                atom = logRG1.atomAt(i);
                atom.addToFx(-dEnergyDrg1*logRG1.dLogRGdX(i));
                atom.addToFy(-dEnergyDrg1*logRG1.dLogRGdY(i));
                atom.addToFz(-dEnergyDrg1*logRG1.dLogRGdZ(i));
        }
        for (int i = 0 ; i<size2;i++) {
                atom = logRG2.atomAt(i);
                atom.addToFx(-dEnergyDrg2*logRG2.dLogRGdX(i));
                atom.addToFy(-dEnergyDrg2*logRG2.dLogRGdY(i));
                atom.addToFz(-dEnergyDrg2*logRG2.dLogRGdZ(i));
        }
        for (int i = 0 ; i<sizeCM;i++) {
                atom = centerOfMass.atomAt(i);
                atom.addToFx(-dEnergyDcmX);
                atom.addToFy(-dEnergyDcmY);
                atom.addToFz(-dEnergyDcmZ);
        }
        return energy;
    }



    
}
      