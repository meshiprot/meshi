package meshi.energy.rg;
import meshi.energy.*;
import meshi.energy.rg.filters.*;
import meshi.molecularElements.*;
import meshi.geometry.*;
import meshi.molecularElements.atoms.AtomList;
import meshi.util.*;
import meshi.util.filters.Filter;
import meshi.util.filters.HeavyAtomsFilter;

/**
 *An implicit solvation energy term for all-atom models, modeling a 4.0 angs solvation shell around
 *each atom.
 **/

public class RgCreator extends EnergyCreator  implements KeyWords {
     private static  Filter hydrophobicSideChains = new HydrophobicSideChains();
     private static  Filter backboneFilter = new BackboneCAs();
     private static  Filter polarFilter = new PolarSideChains();
     private static  Filter heavyAtomsFilter = new HeavyAtomsFilter();
     private static  Filter secondaryStructureFilter = new SecondaryStructureFilter();
     private static  Filter coilFilter = new CoilFilter();
    public RgCreator(double weight) {
	super(weight);
    }

    public RgCreator() {
	super(RG);
    }


    public AbstractEnergy createEnergyTerm(Protein protein, DistanceMatrix distanceMatrix, CommandList commands) {
        // atom lists
        AtomList atomList=protein.atoms();
        AtomList heavyAtoms    = atomList.filter(heavyAtomsFilter);                                                                                                    test(heavyAtoms,"heavyAtomsFilter");
        AtomList nonPolarSS    =  atomList.filter(hydrophobicSideChains).filter(secondaryStructureFilter); test(nonPolarSS,"nonPolarSS");
        AtomList nonPolarCoil=  atomList.filter(hydrophobicSideChains).filter(coilFilter);                                 test(nonPolarCoil,"nonPolarCoil");
        AtomList backboneSS     =  atomList.filter(backboneFilter).filter(secondaryStructureFilter);                 test(backboneSS,"backboneSS");
        AtomList backboneCoil =  atomList.filter(backboneFilter).filter(coilFilter);                                                 test(backboneCoil,"backboneCoil");
        AtomList polarSS             = atomList.filter(polarFilter).filter(secondaryStructureFilter);                        test(polarSS,"polarSS");
        AtomList polarCoil         = atomList.filter(polarFilter).filter(coilFilter);                                                        test(polarCoil,"polarCoil");
        //
        CenterOfMass centerOfMass = new CenterOfMass(nonPolarSS);
        CenterOfMass backboneCenterOfMass = new CenterOfMass(backboneSS);
        //
        // LogRGs
        LogRadiusOfGyration logNonPolarSsRG     = new LogRadiusOfGyration(new RadiusOfGyration(nonPolarSS, centerOfMass));
        LogRadiusOfGyration logNonPolarCoilRG = new LogRadiusOfGyration(new RadiusOfGyration(nonPolarCoil, centerOfMass));
        LogRadiusOfGyration logBackboneSsRG     = new LogRadiusOfGyration(new RadiusOfGyration(backboneSS, centerOfMass));
        LogRadiusOfGyration logBackboneCoilRG = new LogRadiusOfGyration(new RadiusOfGyration(backboneCoil, centerOfMass));
        LogRadiusOfGyration logPolarSsRG             = new LogRadiusOfGyration(new RadiusOfGyration(polarSS, centerOfMass));
        LogRadiusOfGyration logPolarCoilRG         = new LogRadiusOfGyration(new RadiusOfGyration(polarCoil, centerOfMass));
        // pack them
         LogRadiusOfGyration[] logRgArray = {logNonPolarSsRG, logNonPolarCoilRG, logBackboneSsRG, logBackboneCoilRG, logPolarSsRG, logPolarCoilRG};
        Updateable[] updateables = {centerOfMass, backboneCenterOfMass, logNonPolarSsRG, logNonPolarCoilRG, logBackboneSsRG, logBackboneCoilRG, logPolarSsRG, logPolarCoilRG};
				//
         term = new RgEnergy(updateables, logRgArray, Math.log(heavyAtoms.size()), weight);
        return  term;
    }

    public void test(AtomList list, String message) {
                if (list.size() == 0) throw new RuntimeException("Empty list "+message);
    }
}