package meshi.energy.rg.filters;

import meshi.util.filters.Filter;
import meshi.parameters.AtomType;
import meshi.molecularElements.atoms.Atom;

public class PolarSideChains
        implements Filter {
    public PolarSideChains() {
    }


    public boolean accept(Object o) {
        Filter filter = new AtomType.ChargedFilter();
        Atom atom = (Atom) o;
        if (atom.nowhere()) return false;
        if (filter.accept(o)) return true;
        // out1.dat
        if ((atom.type() == AtomType.NND) ||
                (atom.type() == AtomType.NOD) ||
                (atom.type() == AtomType.QNE) ||
                (atom.type() == AtomType.QOE)) return true;
        //
        return false;
    }
}
