package meshi.energy.rg.filters;

import meshi.util.filters.Filter;
import meshi.molecularElements.atoms.Atom;
import meshi.parameters.ResidueType;

/**
 *
 */
public  class HydrophobicSideChains implements Filter {
        public boolean accept(Object o) {
            Atom atom = (Atom) o;
            if (atom.nowhere()) return false;
            if (atom.type().backboneC()) return false;
            if (atom.type().backboneCA()) return false;
            ResidueType residueType=atom.residue().type;
            if (residueType == ResidueType.ARG)    return false;
             if (residueType == ResidueType.CYS)    return false;
            if (residueType == ResidueType.ASP)    return false;
             if (residueType == ResidueType.GLU)    return false;
            if (residueType == ResidueType.LYS)    return false;
             if (residueType == ResidueType.ASN)    return false;
            if (residueType == ResidueType.PRO)    return false;
             if (residueType == ResidueType.GLN)    return false;
            if ((residueType == ResidueType.SER))    return false;
            // if ((residueType == ResidueType.HIS))    return false;
            if (atom.type().isCarbon())return true;
            return false;
        }
    }